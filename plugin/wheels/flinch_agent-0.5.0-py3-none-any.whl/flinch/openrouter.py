"""Judgment via OpenRouter's Decisions API (same typed model, billed to an OpenRouter account).

Endpoint and response shape from OpenRouter's Jev docs (2026-09-27): POST /api/alpha/decisions
with {model, state, questions}; answers come back in the same typed format as the direct API.
"""

import os
from types import MappingProxyType
from typing import Any

import httpx

URL = "https://openrouter.ai/api/alpha/decisions"
DEFAULT_MODEL = "typesafe/jev-1.13"


def openrouter_key() -> str | None:
    env = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if env:
        return env
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    try:
        with open(os.path.join(base, "flinch", "openrouter_api_key")) as f:
            return f.read().strip() or None
    except OSError:
        return None


def _wire(question: Any) -> Any:
    return question.model_dump() if hasattr(question, "model_dump") else question


class OpenRouterJevClient:
    """Duck-types TypeSafeClient.system_one, returning the SDK's own SystemOneResponse."""

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL, timeout: float = 1.5,
                 http: httpx.Client | None = None) -> None:
        self._headers = MappingProxyType({"Authorization": f"Bearer {api_key}", "Content-Type": "application/json",
                                          "X-Title": "Flinch"})
        self._model = model or DEFAULT_MODEL
        self._http = http or httpx.Client(timeout=timeout)

    def system_one(self, state: Any, questions: dict[str, Any], **_: Any):
        from typesafe_sdk import SystemOneResponse

        body = {"model": self._model, "state": state, "questions": {k: _wire(q) for k, q in questions.items()}}
        r = self._http.post(URL, json=body, headers=dict(self._headers))
        if r.status_code != 200:
            try:
                message = r.json().get("error", {}).get("message", "")
            except ValueError:
                message = r.text[:120]
            raise RuntimeError(f"openrouter {r.status_code}: {message[:160]}")
        data = r.json()
        answers = data.get("answers") or {}
        usage = data.get("usage") or {}
        clean = {"model": data.get("model", self._model), "answers": answers,
                 "usage": {"input_tokens": usage.get("input_tokens"), "output_tokens": usage.get("output_tokens")}}
        return SystemOneResponse.model_validate_json(httpx.Response(200, json=clean).content)
