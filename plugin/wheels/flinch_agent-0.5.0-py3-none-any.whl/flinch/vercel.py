"""Judgment via Vercel AI Gateway's evaluation endpoint (model `typesafe-ai/jev`).

Verified 2026-09-27 against https://ai-gateway.vercel.sh/v1/evaluate: request shape matches the
direct API except yes/no questions use type "boolean" (not "noul"). The response shape could not
be observed yet (account needed a card on file), so yes/no answers are read tolerantly and anything
unrecognized is treated as unavailable by the caller.
"""

import os
from typing import Any

import httpx

URL = "https://ai-gateway.vercel.sh/v1/evaluate"
MODEL = "typesafe-ai/jev"
_PROBABILITY_KEYS = ("noul", "probability", "p_true", "true", "yes", "value")


def vercel_key() -> str | None:
    env = os.environ.get("AI_GATEWAY_API_KEY", "").strip()
    if env:
        return env
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    try:
        with open(os.path.join(base, "flinch", "vercel_ai_gateway_key")) as f:
            return f.read().strip() or None
    except OSError:
        return None


def _wire(question: Any) -> dict[str, Any]:
    q = question.model_dump() if hasattr(question, "model_dump") else dict(question)
    return {**q, "type": "boolean"} if q.get("type") == "noul" else q


def _as_noul(answer: dict[str, Any]) -> dict[str, Any]:
    if answer.get("type") not in ("boolean", "noul"):
        return answer
    for key in _PROBABILITY_KEYS:
        value = answer.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return {"type": "noul", "noul": float(value)}
    probs = answer.get("probabilities") or {}
    for key in ("true", "yes", True):
        if key in probs:
            return {"type": "noul", "noul": float(probs[key])}
    raise ValueError(f"unrecognized boolean answer: {sorted(answer)}")


class VercelJevClient:
    """Duck-types TypeSafeClient.system_one, returning the SDK's own SystemOneResponse."""

    def __init__(self, api_key: str, timeout: float = 1.5, http: httpx.Client | None = None) -> None:
        self._auth = f"Bearer {api_key}"
        self._http = http or httpx.Client(timeout=timeout)

    def system_one(self, state: Any, questions: dict[str, Any], **_: Any):
        from typesafe_sdk import SystemOneResponse

        body = {"model": MODEL, "state": state, "questions": {k: _wire(q) for k, q in questions.items()}}
        r = self._http.post(URL, json=body, headers={"Authorization": self._auth})
        if r.status_code != 200:
            try:
                message = r.json().get("error", {}).get("message", "")
            except ValueError:
                message = r.text[:120]
            raise RuntimeError(f"vercel {r.status_code}: {message[:160]}")
        data = r.json()
        answers = {k: _as_noul(v) for k, v in (data.get("answers") or {}).items()}
        usage = data.get("usage") or {}
        clean = {"model": data.get("model", MODEL), "answers": answers,
                 "usage": {"input_tokens": usage.get("input_tokens"), "output_tokens": usage.get("output_tokens")}}
        return SystemOneResponse.model_validate_json(httpx.Response(200, json=clean).content)
