"""Judgment gate for never-seen actions (SPEC §8), with a hard timeout and silent fallback.

All thresholds and arithmetic live here, never in the questions.
"""

import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeout
from dataclasses import dataclass
from typing import Any

from flinch.config import Config
from flinch.openrouter import OpenRouterJevClient, openrouter_key
from flinch.vercel import VercelJevClient, vercel_key

log = logging.getLogger("flinch")

RESEMBLES_PAIN_DENY = 0.7
PAUSE_AFTER_ACCOUNT_ERROR_S = 600  # 401/402/403 won't fix themselves between two commands
_ACCOUNT_ERRORS = (" 401", " 402", " 403", "AuthenticationError", "PermissionDenied")
DESTRUCTIVE_ASK_CONFIDENCE = 0.6
MAX_PAST_PAIN = 3


@dataclass(frozen=True)
class JudgeVerdict:
    decision: str  # deny | ask | pass
    effect: str
    effect_confidence: float
    resembles_pain: float
    reason: str | None


def api_key() -> str | None:
    """Env var first, else ~/.config/flinch/typesafe_api_key (so the key never sits in a shell rc)."""
    env = os.environ.get("TYPESAFE_API_KEY", "").strip()
    if env:
        return env
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    try:
        with open(os.path.join(base, "flinch", "typesafe_api_key")) as f:
            return f.read().strip() or None
    except OSError:
        return None


def _is_account_error(message: str) -> bool:
    return any(marker in message for marker in _ACCOUNT_ERRORS)


def _all_account_errors(message: str) -> bool:
    parts = [p for p in message.split("; ") if p.strip()]
    return bool(parts) and all(_is_account_error(p) or ": paused after " in p for p in parts)


class ChainClient:
    """Tries each configured backend in order; one with an account/billing error is skipped for a while."""

    def __init__(self, backends: list[tuple[str, Any]]) -> None:
        self._backends = backends
        self._paused: dict[str, float] = {}
        self._reasons: dict[str, str] = {}
        self.active: str | None = None

    def system_one(self, state: Any, questions: dict[str, Any], **kw: Any) -> Any:
        errors = []
        for name, client in self._backends:
            if time.time() < self._paused.get(name, 0.0):
                errors.append(f"{name}: paused after {self._reasons.get(name, 'an account error')}")
                continue
            try:
                result = client.system_one(state, questions, **kw)
            except Exception as e:  # noqa: BLE001 - fall through to the next backend
                message = f"{type(e).__name__}: {str(e)[:160]}"
                errors.append(message)
                if _is_account_error(message):
                    self._paused = {**self._paused, name: time.time() + PAUSE_AFTER_ACCOUNT_ERROR_S}
                    self._reasons = {**self._reasons, name: str(e)[:160]}
                continue
            self.active = name
            return result
        raise RuntimeError("; ".join(errors) or "no judgment backend")


def _default_client(config: Config, timeout: float) -> Any:
    """Every backend with a key, in order: direct API, Vercel AI Gateway, OpenRouter."""
    backends: list[tuple[str, Any]] = []
    key = api_key()
    if key:
        from typesafe_sdk import RetryPolicy, TypeSafeClient

        # SDK defaults are a 10 s timeout and 2 retries: far too slow for a pre-tool hook.
        backends.append(("typesafe", TypeSafeClient(api_key=key, model=config.judgment_model or None,
                                                    retry=RetryPolicy(max_retries=0), timeout=timeout)))
    if vercel_key():
        backends.append(("vercel", VercelJevClient(vercel_key(), timeout=timeout)))
    if openrouter_key():
        backends.append(("openrouter", OpenRouterJevClient(openrouter_key(), timeout=timeout)))
    return ChainClient(backends) if backends else None


class Judge:
    def __init__(self, config: Config, client: Any = None) -> None:
        self._timeout = config.judgment_timeout_s
        self._client = None
        self._status = "disabled"
        self.last_error: str | None = None
        self._paused_until = 0.0
        if not config.judgment_enabled:
            return
        if client is None:
            client = _default_client(config, self._timeout)
        if client is not None:
            self._client = client
            self._status = "ok"
            self._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="judge")

    @property
    def status(self) -> str:
        return self._status

    @property
    def available(self) -> bool:
        return self._client is not None

    def ask(self, state: Any, questions: dict[str, Any]) -> Any | None:
        """One request, all questions in parallel. None on any failure or timeout."""
        if self._client is None or time.time() < self._paused_until:
            return None
        future = self._pool.submit(self._client.system_one, state, questions)
        try:
            result = future.result(timeout=self._timeout)
        except FutureTimeout:
            log.warning("judgment: unavailable (timeout after %.1fs)", self._timeout)
            self._status, self.last_error = "unavailable", f"timeout after {self._timeout}s"
            return None
        except Exception as e:  # noqa: BLE001 - never let judgment failure block the agent
            self._status, self.last_error = "unavailable", f"{type(e).__name__}: {str(e)[:200]}"
            if _all_account_errors(self.last_error):
                self._paused_until = time.time() + PAUSE_AFTER_ACCOUNT_ERROR_S
                self.last_error += f" (paused {PAUSE_AFTER_ACCOUNT_ERROR_S // 60} min)"
            log.warning("judgment: unavailable (%s)", self.last_error)
            return None
        self._status, self.last_error = "ok", None
        return result


def _questions() -> dict[str, Any]:
    from typesafe_sdk import Choice, Noul

    return {
        "effect": Choice(
            instructions="What will running `action` do to files, data, or remote systems?",
            criteria={
                "read_only": "Only reads or inspects. Changes nothing.",
                "reversible": "Changes things, but they are easily undone (e.g. git-tracked edits, creating files).",
                "destructive": "Deletes, overwrites, or changes data or remote state in a way that is hard or "
                               "impossible to undo.",
            }),
        "resembles_pain": Noul(instructions="Does `action` risk the same kind of damage described in `past_pain`?"),
    }


def judge_action(judge: Judge, tool: str, action: str, rel_cwd: str, past_pain: list[str]) -> JudgeVerdict | None:
    state = {"tool": tool, "action": action, "cwd": rel_cwd, "past_pain": past_pain[:MAX_PAST_PAIN]}
    r = judge.ask(state, _questions())
    if r is None:
        return None
    try:
        effect = r.choices["effect"]
        resembles = float(r.nouls["resembles_pain"].noul) if past_pain else 0.0
    except (KeyError, AttributeError, TypeError, ValueError):
        log.warning("judgment: malformed response; ignoring")
        return None
    if resembles >= RESEMBLES_PAIN_DENY:
        return JudgeVerdict("deny", effect.choice, effect.confidence, resembles,
                            f"Flinch judgment: this action risks the same kind of damage as a past pain memory "
                            f"({past_pain[0]}).")
    if effect.choice == "destructive" and effect.confidence >= DESTRUCTIVE_ASK_CONFIDENCE:
        return JudgeVerdict("ask", effect.choice, effect.confidence, resembles,
                            f"Flinch judgment: this action looks destructive and hard to undo "
                            f"(confidence {effect.confidence:.2f}). Confirm only if intended.")
    return JudgeVerdict("pass", effect.choice, effect.confidence, resembles, None)
